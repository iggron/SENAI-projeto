<?php
$conexao = new mysqli('localhost', 'root', 'Home@spSENAI2025!', 'empresa');
$cpf = $_POST['cpf'];

$sql = "SELECT * FROM funcionarios WHERE cpf = '$cpf'"; 
$resultado = $conexao->query($sql);

if ($resultado->num_rows > 0) {
    $cliente = $resultado->fetch_assoc();
?>
<form action="CRUDALT2.php" method="POST">
  <input type="hidden" name="cpf" value="<?php echo $cliente['cpf']; ?>">

  <label>Nome Atual:</label>
  <input type="text" name="nome" value="<?php echo $cliente['nome']; ?>" required>

  <label>E-matricula Atual:</label>
  <input type="text" name="matricula" value="<?php echo $cliente['matricula']; ?>" required>

  <button type="submit">Gravar Alterações</button>
</form> 
<?php } else { echo "Funcionario não localizado."; } ?> 